```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
data = pd.read_csv(r"D:\Yashada Docs\Practise Projects\Using Python\IMDB-Movie-Data.csv")
```


```python
1: DISPPLAY TOP 10 ROWS OFF THE DATATSET 
```


```python
data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>The Great Wall</td>
      <td>Action,Adventure,Fantasy</td>
      <td>European mercenaries searching for black powde...</td>
      <td>Yimou Zhang</td>
      <td>Matt Damon, Tian Jing, Willem Dafoe, Andy Lau</td>
      <td>2016</td>
      <td>103</td>
      <td>6.1</td>
      <td>56036</td>
      <td>45.13</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>La La Land</td>
      <td>Comedy,Drama,Music</td>
      <td>A jazz pianist falls for an aspiring actress i...</td>
      <td>Damien Chazelle</td>
      <td>Ryan Gosling, Emma Stone, Rosemarie DeWitt, J....</td>
      <td>2016</td>
      <td>128</td>
      <td>8.3</td>
      <td>258682</td>
      <td>151.06</td>
      <td>93.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>Mindhorn</td>
      <td>Comedy</td>
      <td>A has-been actor best known for playing the ti...</td>
      <td>Sean Foley</td>
      <td>Essie Davis, Andrea Riseborough, Julian Barrat...</td>
      <td>2016</td>
      <td>89</td>
      <td>6.4</td>
      <td>2490</td>
      <td>NaN</td>
      <td>71.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>The Lost City of Z</td>
      <td>Action,Adventure,Biography</td>
      <td>A true-life drama, centering on British explor...</td>
      <td>James Gray</td>
      <td>Charlie Hunnam, Robert Pattinson, Sienna Mille...</td>
      <td>2016</td>
      <td>141</td>
      <td>7.1</td>
      <td>7188</td>
      <td>8.01</td>
      <td>78.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>Passengers</td>
      <td>Adventure,Drama,Romance</td>
      <td>A spacecraft traveling to a distant colony pla...</td>
      <td>Morten Tyldum</td>
      <td>Jennifer Lawrence, Chris Pratt, Michael Sheen,...</td>
      <td>2016</td>
      <td>116</td>
      <td>7.0</td>
      <td>192177</td>
      <td>100.01</td>
      <td>41.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
2: DISPLAY LAST 10 RECORDS
```


```python
data.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>990</th>
      <td>991</td>
      <td>Underworld: Rise of the Lycans</td>
      <td>Action,Adventure,Fantasy</td>
      <td>An origins story centered on the centuries-old...</td>
      <td>Patrick Tatopoulos</td>
      <td>Rhona Mitra, Michael Sheen, Bill Nighy, Steven...</td>
      <td>2009</td>
      <td>92</td>
      <td>6.6</td>
      <td>129708</td>
      <td>45.80</td>
      <td>44.0</td>
    </tr>
    <tr>
      <th>991</th>
      <td>992</td>
      <td>Taare Zameen Par</td>
      <td>Drama,Family,Music</td>
      <td>An eight-year-old boy is thought to be a lazy ...</td>
      <td>Aamir Khan</td>
      <td>Darsheel Safary, Aamir Khan, Tanay Chheda, Sac...</td>
      <td>2007</td>
      <td>165</td>
      <td>8.5</td>
      <td>102697</td>
      <td>1.20</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>992</th>
      <td>993</td>
      <td>Take Me Home Tonight</td>
      <td>Comedy,Drama,Romance</td>
      <td>Four years after graduation, an awkward high s...</td>
      <td>Michael Dowse</td>
      <td>Topher Grace, Anna Faris, Dan Fogler, Teresa P...</td>
      <td>2011</td>
      <td>97</td>
      <td>6.3</td>
      <td>45419</td>
      <td>6.92</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>Resident Evil: Afterlife</td>
      <td>Action,Adventure,Horror</td>
      <td>While still out to destroy the evil Umbrella C...</td>
      <td>Paul W.S. Anderson</td>
      <td>Milla Jovovich, Ali Larter, Wentworth Miller,K...</td>
      <td>2010</td>
      <td>97</td>
      <td>5.9</td>
      <td>140900</td>
      <td>60.13</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Project X</td>
      <td>Comedy</td>
      <td>3 high school seniors throw a birthday party t...</td>
      <td>Nima Nourizadeh</td>
      <td>Thomas Mann, Oliver Cooper, Jonathan Daniel Br...</td>
      <td>2012</td>
      <td>88</td>
      <td>6.7</td>
      <td>164088</td>
      <td>54.72</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Secret in Their Eyes</td>
      <td>Crime,Drama,Mystery</td>
      <td>A tight-knit team of rising investigators, alo...</td>
      <td>Billy Ray</td>
      <td>Chiwetel Ejiofor, Nicole Kidman, Julia Roberts...</td>
      <td>2015</td>
      <td>111</td>
      <td>6.2</td>
      <td>27585</td>
      <td>NaN</td>
      <td>45.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Search Party</td>
      <td>Adventure,Comedy</td>
      <td>A pair of friends embark on a mission to reuni...</td>
      <td>Scot Armstrong</td>
      <td>Adam Pally, T.J. Miller, Thomas Middleditch,Sh...</td>
      <td>2014</td>
      <td>93</td>
      <td>5.6</td>
      <td>4881</td>
      <td>NaN</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
3: FIND THE SHAPE OF DATASET
```


```python
data.shape
```




    (1000, 12)




```python
4: GETTING THE INFORMATION ABOUT THE DATASET
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1000 entries, 0 to 999
    Data columns (total 12 columns):
     #   Column              Non-Null Count  Dtype  
    ---  ------              --------------  -----  
     0   Rank                1000 non-null   int64  
     1   Title               1000 non-null   object 
     2   Genre               1000 non-null   object 
     3   Description         1000 non-null   object 
     4   Director            1000 non-null   object 
     5   Actors              1000 non-null   object 
     6   Year                1000 non-null   int64  
     7   Runtime (Minutes)   1000 non-null   int64  
     8   Rating              1000 non-null   float64
     9   Votes               1000 non-null   int64  
     10  Revenue (Millions)  872 non-null    float64
     11  Metascore           936 non-null    float64
    dtypes: float64(3), int64(4), object(5)
    memory usage: 93.9+ KB
    


```python
5: CHECK NULL VALUES 
```


```python
data.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>996</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>997</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>998</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>999</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 12 columns</p>
</div>




```python
print ("is their any missing values?",data.isnull().values.any())
```

    is their any missing values? True
    


```python
data.isnull().sum()
```




    Rank                    0
    Title                   0
    Genre                   0
    Description             0
    Director                0
    Actors                  0
    Year                    0
    Runtime (Minutes)       0
    Rating                  0
    Votes                   0
    Revenue (Millions)    128
    Metascore              64
    dtype: int64




```python
sns.heatmap(data.isnull())
```




    <Axes: >




    
![png](output_14_1.png)
    



```python
6: REMOVE MISSING VALUES
```


```python
data.dropna(axis=0)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>993</th>
      <td>994</td>
      <td>Resident Evil: Afterlife</td>
      <td>Action,Adventure,Horror</td>
      <td>While still out to destroy the evil Umbrella C...</td>
      <td>Paul W.S. Anderson</td>
      <td>Milla Jovovich, Ali Larter, Wentworth Miller,K...</td>
      <td>2010</td>
      <td>97</td>
      <td>5.9</td>
      <td>140900</td>
      <td>60.13</td>
      <td>37.0</td>
    </tr>
    <tr>
      <th>994</th>
      <td>995</td>
      <td>Project X</td>
      <td>Comedy</td>
      <td>3 high school seniors throw a birthday party t...</td>
      <td>Nima Nourizadeh</td>
      <td>Thomas Mann, Oliver Cooper, Jonathan Daniel Br...</td>
      <td>2012</td>
      <td>88</td>
      <td>6.7</td>
      <td>164088</td>
      <td>54.72</td>
      <td>48.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>838 rows × 12 columns</p>
</div>




```python
data.isnull().sum()
```




    Rank                    0
    Title                   0
    Genre                   0
    Description             0
    Director                0
    Actors                  0
    Year                    0
    Runtime (Minutes)       0
    Rating                  0
    Votes                   0
    Revenue (Millions)    128
    Metascore              64
    dtype: int64




```python
7: CHECK DUPLICATE VALUE
```


```python
dup_data = data.duplicated().any()
```


```python
print("any duplicated values",dup_data)
```

    any duplicated values False
    


```python
data = data.drop_duplicates()
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>Split</td>
      <td>Horror,Thriller</td>
      <td>Three girls are kidnapped by a man with a diag...</td>
      <td>M. Night Shyamalan</td>
      <td>James McAvoy, Anya Taylor-Joy, Haley Lu Richar...</td>
      <td>2016</td>
      <td>117</td>
      <td>7.3</td>
      <td>157606</td>
      <td>138.12</td>
      <td>62.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>Sing</td>
      <td>Animation,Comedy,Family</td>
      <td>In a city of humanoid animals, a hustling thea...</td>
      <td>Christophe Lourdelet</td>
      <td>Matthew McConaughey,Reese Witherspoon, Seth Ma...</td>
      <td>2016</td>
      <td>108</td>
      <td>7.2</td>
      <td>60545</td>
      <td>270.32</td>
      <td>59.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>Suicide Squad</td>
      <td>Action,Adventure,Fantasy</td>
      <td>A secret government agency recruits some of th...</td>
      <td>David Ayer</td>
      <td>Will Smith, Jared Leto, Margot Robbie, Viola D...</td>
      <td>2016</td>
      <td>123</td>
      <td>6.2</td>
      <td>393727</td>
      <td>325.02</td>
      <td>40.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>995</th>
      <td>996</td>
      <td>Secret in Their Eyes</td>
      <td>Crime,Drama,Mystery</td>
      <td>A tight-knit team of rising investigators, alo...</td>
      <td>Billy Ray</td>
      <td>Chiwetel Ejiofor, Nicole Kidman, Julia Roberts...</td>
      <td>2015</td>
      <td>111</td>
      <td>6.2</td>
      <td>27585</td>
      <td>NaN</td>
      <td>45.0</td>
    </tr>
    <tr>
      <th>996</th>
      <td>997</td>
      <td>Hostel: Part II</td>
      <td>Horror</td>
      <td>Three American college students studying abroa...</td>
      <td>Eli Roth</td>
      <td>Lauren German, Heather Matarazzo, Bijou Philli...</td>
      <td>2007</td>
      <td>94</td>
      <td>5.5</td>
      <td>73152</td>
      <td>17.54</td>
      <td>46.0</td>
    </tr>
    <tr>
      <th>997</th>
      <td>998</td>
      <td>Step Up 2: The Streets</td>
      <td>Drama,Music,Romance</td>
      <td>Romantic sparks occur between two dance studen...</td>
      <td>Jon M. Chu</td>
      <td>Robert Hoffman, Briana Evigan, Cassie Ventura,...</td>
      <td>2008</td>
      <td>98</td>
      <td>6.2</td>
      <td>70699</td>
      <td>58.01</td>
      <td>50.0</td>
    </tr>
    <tr>
      <th>998</th>
      <td>999</td>
      <td>Search Party</td>
      <td>Adventure,Comedy</td>
      <td>A pair of friends embark on a mission to reuni...</td>
      <td>Scot Armstrong</td>
      <td>Adam Pally, T.J. Miller, Thomas Middleditch,Sh...</td>
      <td>2014</td>
      <td>93</td>
      <td>5.6</td>
      <td>4881</td>
      <td>NaN</td>
      <td>22.0</td>
    </tr>
    <tr>
      <th>999</th>
      <td>1000</td>
      <td>Nine Lives</td>
      <td>Comedy,Family,Fantasy</td>
      <td>A stuffy businessman finds himself trapped ins...</td>
      <td>Barry Sonnenfeld</td>
      <td>Kevin Spacey, Jennifer Garner, Robbie Amell,Ch...</td>
      <td>2016</td>
      <td>87</td>
      <td>5.3</td>
      <td>12435</td>
      <td>19.64</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
<p>1000 rows × 12 columns</p>
</div>




```python
8: GET OVERALL STATISTICS ABOUT DATASET
```


```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1.000000e+03</td>
      <td>872.000000</td>
      <td>936.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>500.500000</td>
      <td>2012.783000</td>
      <td>113.172000</td>
      <td>6.723200</td>
      <td>1.698083e+05</td>
      <td>82.956376</td>
      <td>58.985043</td>
    </tr>
    <tr>
      <th>std</th>
      <td>288.819436</td>
      <td>3.205962</td>
      <td>18.810908</td>
      <td>0.945429</td>
      <td>1.887626e+05</td>
      <td>103.253540</td>
      <td>17.194757</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2006.000000</td>
      <td>66.000000</td>
      <td>1.900000</td>
      <td>6.100000e+01</td>
      <td>0.000000</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>250.750000</td>
      <td>2010.000000</td>
      <td>100.000000</td>
      <td>6.200000</td>
      <td>3.630900e+04</td>
      <td>13.270000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>500.500000</td>
      <td>2014.000000</td>
      <td>111.000000</td>
      <td>6.800000</td>
      <td>1.107990e+05</td>
      <td>47.985000</td>
      <td>59.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>750.250000</td>
      <td>2016.000000</td>
      <td>123.000000</td>
      <td>7.400000</td>
      <td>2.399098e+05</td>
      <td>113.715000</td>
      <td>72.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.000000</td>
      <td>2016.000000</td>
      <td>191.000000</td>
      <td>9.000000</td>
      <td>1.791916e+06</td>
      <td>936.630000</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
9: Display the title of the movie having runtime >= 180 minutes
```


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data[data['Runtime (Minutes)']>=180],['Title']
```




    (     Rank                    Title                   Genre  \
     82     83  The Wolf of Wall Street  Biography,Comedy,Crime   
     88     89        The Hateful Eight     Crime,Drama,Mystery   
     311   312           La vie d'Adèle           Drama,Romance   
     828   829               Grindhouse  Action,Horror,Thriller   
     965   966            Inland Empire  Drama,Mystery,Thriller   
     
                                                Description             Director  \
     82   Based on the true story of Jordan Belfort, fro...      Martin Scorsese   
     88   In the dead of a Wyoming winter, a bounty hunt...    Quentin Tarantino   
     311  Adèle's life is changed when she meets Emma, a...  Abdellatif Kechiche   
     828  Quentin Tarantino and Robert Rodriguez's homag...     Robert Rodriguez   
     965  As an actress starts to adopt the persona of h...          David Lynch   
     
                                                     Actors  Year  \
     82   Leonardo DiCaprio, Jonah Hill, Margot Robbie,M...  2013   
     88   Samuel L. Jackson, Kurt Russell, Jennifer Jaso...  2015   
     311  Léa Seydoux, Adèle Exarchopoulos, Salim Kechio...  2013   
     828  Kurt Russell, Rose McGowan, Danny Trejo, Zoë Bell  2007   
     965  Laura Dern, Jeremy Irons, Justin Theroux, Karo...  2006   
     
          Runtime (Minutes)  Rating   Votes  Revenue (Millions)  Metascore  
     82                 180     8.2  865134              116.87       75.0  
     88                 187     7.8  341170               54.12       68.0  
     311                180     7.8  103150                2.20       88.0  
     828                191     7.6  160350               25.03        NaN  
     965                180     7.0   44227                 NaN        NaN  ,
     ['Title'])




```python
10: IN WHICH YEAR THERE WAS HIGHEST AVG VOTING ?
```


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
data.groupby('Year')['Votes'].mean().sort_values(ascending = False)
```




    Year
    2012    285226.093750
    2008    275505.384615
    2006    269289.954545
    2009    255780.647059
    2010    252782.316667
    2007    244331.037736
    2011    240790.301587
    2013    219049.648352
    2014    203930.224490
    2015    115726.220472
    2016     48591.754209
    Name: Votes, dtype: float64




```python
data.groupby('Year')['Votes'].mean().sort_values(ascending = False)
```




    Year
    2012    285226.093750
    2008    275505.384615
    2006    269289.954545
    2009    255780.647059
    2010    252782.316667
    2007    244331.037736
    2011    240790.301587
    2013    219049.648352
    2014    203930.224490
    2015    115726.220472
    2016     48591.754209
    Name: Votes, dtype: float64




```python
sns.barplot(x ='Year',y ='Votes',data=data)
```




    <Axes: xlabel='Year', ylabel='Votes'>




    
![png](output_31_1.png)
    



```python
11. IN WHICH YEAR THERE IS HIGHEST AVG REVENUE?
```


```python
data.groupby('Year')['Revenue (Millions)'].mean().sort_values(ascending = False)
```




    Year
    2009    112.601277
    2012    107.973281
    2010    105.081579
    2008     99.082745
    2007     87.882245
    2011     87.612258
    2013     87.121818
    2006     86.296667
    2014     85.078723
    2015     78.355044
    2016     54.690976
    Name: Revenue (Millions), dtype: float64




```python
sns.barplot(x ='Year',y ='Revenue (Millions)',data=data)
```




    <Axes: xlabel='Year', ylabel='Revenue (Millions)'>




    
![png](output_34_1.png)
    



```python
12: FIND THE AVG RATING FOR EACH DIRECTOR
```


```python
data.groupby('Director')['Rating'].mean().sort_values()
```




    Director
    Jason Friedberg                     1.90
    Shawn Burkett                       2.70
    James Wong                          2.70
    Jonathan Holbrook                   3.20
    Micheal Bafaro                      3.50
                                        ... 
    Florian Henckel von Donnersmarck    8.50
    Olivier Nakache                     8.60
    Makoto Shinkai                      8.60
    Christopher Nolan                   8.68
    Nitesh Tiwari                       8.80
    Name: Rating, Length: 644, dtype: float64




```python
13: DISPLAY TOP 10 LENGTHY MOVIES AND RUNTIME
```


```python
data.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
top_10 = data.nlargest(10,'Runtime (Minutes)')[['Title','Runtime (Minutes)']]\
.set_index('Title')
```


```python
top_10 
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Runtime (Minutes)</th>
    </tr>
    <tr>
      <th>Title</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Grindhouse</th>
      <td>191</td>
    </tr>
    <tr>
      <th>The Hateful Eight</th>
      <td>187</td>
    </tr>
    <tr>
      <th>The Wolf of Wall Street</th>
      <td>180</td>
    </tr>
    <tr>
      <th>La vie d'Adèle</th>
      <td>180</td>
    </tr>
    <tr>
      <th>Inland Empire</th>
      <td>180</td>
    </tr>
    <tr>
      <th>Cloud Atlas</th>
      <td>172</td>
    </tr>
    <tr>
      <th>3 Idiots</th>
      <td>170</td>
    </tr>
    <tr>
      <th>Interstellar</th>
      <td>169</td>
    </tr>
    <tr>
      <th>Pirates of the Caribbean: At World's End</th>
      <td>169</td>
    </tr>
    <tr>
      <th>The Hobbit: An Unexpected Journey</th>
      <td>169</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
